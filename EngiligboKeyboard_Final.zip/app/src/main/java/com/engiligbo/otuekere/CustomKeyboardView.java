package com.engiligbo.otuekere;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.util.AttributeSet;

public class CustomKeyboardView extends KeyboardView {

    private int keyTextColor = 0xFF000000; // default black
    private final Paint paint = new Paint();

    public CustomKeyboardView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomKeyboardView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setKeyTextColor(int color) {
        keyTextColor = color;
        invalidate();
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Keyboard keyboard = getKeyboard();
        if (keyboard == null) return;

        paint.setAntiAlias(true);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(32);

        for (Keyboard.Key key : keyboard.getKeys()) {
            if (key.label != null) {
                paint.setColor(keyTextColor);
                float x = key.x + key.width / 2f;
                float y = key.y + key.height / 2f + paint.getTextSize()/3f;
                canvas.drawText(key.label.toString(), x, y, paint);
            }
        }
    }
}
