package com.engiligbo.otuekere;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;

public class PreviewKeyboardActivity extends AppCompatActivity {

    private KeyboardView previewKeyboardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview_keyboard);
        previewKeyboardView = findViewById(R.id.previewKeyboardView);
        Keyboard keyboard = new Keyboard(this, R.xml.keyboard_igbo);
        previewKeyboardView.setKeyboard(keyboard);
        previewKeyboardView.setPreviewEnabled(false);
    }
}
