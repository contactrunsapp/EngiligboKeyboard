package com.engiligbo.otuekere;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class EngiligboIME extends InputMethodService implements KeyboardView.OnKeyboardActionListener {
    private static final String TAG = "EngiligboIME";

    private CustomKeyboardView kv;
    private Keyboard keyboardIgbo, keyboardEnglish, keyboardNumbers, keyboardSymbols, keyboardSymbolsMore;
    private Keyboard emojiPage1, emojiPage2, emojiPage3;

    private TextView translationText;
    private LinearLayout suggestionsLayout;

    private JSONObject dictionary;
    private JSONObject ngrams;

    private boolean isIgbo = true;
    private boolean isShift = false;
    private int emojiPage = 1;

    private SharedPreferences prefs;
    private static final String PREFS = "engiligbo_prefs";
    private static final String KEY_DARK = "dark_mode";
    private static final String KEY_TRANSLATE = "translate_enabled";

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        loadDictionary();
    }

    @Override
    public View onCreateInputView() {
        View root = LayoutInflater.from(this).inflate(R.layout.translation_suggestions_container, null);

        translationText = root.findViewById(R.id.translationText);
        suggestionsLayout = root.findViewById(R.id.suggestionsLayout);
        kv = root.findViewById(R.id.keyboard);

        // load keyboards
        keyboardIgbo = new Keyboard(this, R.xml.keyboard_igbo);
        keyboardEnglish = new Keyboard(this, R.xml.keyboard_english);
        keyboardNumbers = new Keyboard(this, R.xml.keyboard_numbers);
        keyboardSymbols = new Keyboard(this, R.xml.keyboard_symbols);
        keyboardSymbolsMore = new Keyboard(this, R.xml.keyboard_symbols_more);
        emojiPage1 = new Keyboard(this, R.xml.emoji_page1);
        emojiPage2 = new Keyboard(this, R.xml.emoji_page2);
        emojiPage3 = new Keyboard(this, R.xml.emoji_page3);

        kv.setKeyboard(isIgbo ? keyboardIgbo : keyboardEnglish);
        kv.setOnKeyboardActionListener(this);
        kv.setPreviewEnabled(false);

        applyTheme();
        updateBars();

        return root;
    }

    private void loadDictionary() {
        try {
            InputStream is = getAssets().open("dictionary.json");
            byte[] b = new byte[is.available()];
            is.read(b);
            String json = new String(b, StandardCharsets.UTF_8);
            dictionary = new JSONObject(json);
        } catch (Exception e) {
            Log.e(TAG, "loadDictionary", e);
            dictionary = new JSONObject();
        }
    }

    private void commitCode(InputConnection ic, int code) {
        if (ic == null) return;
        try {
            if (code > 0xFFFF) {
                ic.commitText(new String(Character.toChars(code)), 1);
            } else {
                ic.commitText(String.valueOf((char) code), 1);
            }
        } catch (Exception e) {
            Log.e(TAG, "commitCode", e);
        }
    }

    private void updateBars() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        CharSequence before = ic.getTextBeforeCursor(200, 0);
        if (before == null) before = "";
        String full = before.toString().trim();

        boolean translateEnabled = prefs.getBoolean(KEY_TRANSLATE, true);
        if (!translateEnabled || full.isEmpty()) {
            translationText.setText("");
        } else {
            translationText.setText(translateSentence(full));
        }

        suggestionsLayout.removeAllViews();
        if (!full.isEmpty()) {
            String[] parts = full.split("\\s+");
            String last = parts[parts.length - 1].toLowerCase(Locale.ROOT);
            if (!last.isEmpty()) buildSuggestions(last);
        }
    }

    private String translateSentence(String sentence) {
        try {
            StringBuilder out = new StringBuilder();
            String[] words = sentence.split("\\s+");
            for (String w : words) {
                if (w.trim().isEmpty()) continue;
                String t = lookupTranslation(w.toLowerCase(Locale.ROOT));
                out.append(t).append(" ");
            }
            return out.toString().trim();
        } catch (Exception e) {
            return "";
        }
    }

    private String lookupTranslation(String word) {
        try {
            if (dictionary.has(word)) {
                Object val = dictionary.get(word);
                if (val instanceof JSONArray) {
                    JSONArray arr = (JSONArray) val;
                    if (arr.length() > 0) return arr.optString(0, word);
                } else {
                    return String.valueOf(val);
                }
            }
            Iterator<String> keys = dictionary.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                Object v = dictionary.opt(k);
                if (v instanceof JSONArray) {
                    JSONArray arr = (JSONArray) v;
                    for (int i = 0; i < arr.length(); i++) {
                        if (arr.optString(i).equalsIgnoreCase(word)) return k;
                    }
                } else {
                    if (String.valueOf(v).equalsIgnoreCase(word)) return k;
                }
            }
        } catch (Exception ignored) {}
        return word;
    }

    private void buildSuggestions(String word) {
        try {
            int max = 8;
            int count = 0;
            Iterator<String> keys = dictionary.keys();
            List<String> suggestions = new ArrayList<>();

            while (keys.hasNext() && count < 200) {
                String k = keys.next();
                if (k.toLowerCase(Locale.ROOT).startsWith(word)) {
                    Object v = dictionary.opt(k);
                    if (v instanceof JSONArray) {
                        JSONArray arr = (JSONArray) v;
                        for (int i = 0; i < arr.length() && suggestions.size() < max; i++) {
                            suggestions.add(arr.optString(i));
                        }
                    } else {
                        suggestions.add(String.valueOf(v));
                    }
                    count++;
                    if (suggestions.size() >= max) break;
                }
            }

            if (suggestions.isEmpty()) {
                keys = dictionary.keys();
                while (keys.hasNext() && suggestions.size() < max) {
                    String k = keys.next();
                    if (k.toLowerCase(Locale.ROOT).contains(word)) {
                        Object v = dictionary.opt(k);
                        if (v instanceof JSONArray) {
                            JSONArray arr = (JSONArray) v;
                            for (int i = 0; i < arr.length() && suggestions.size() < max; i++) {
                                suggestions.add(arr.optString(i));
                            }
                        } else {
                            suggestions.add(String.valueOf(v));
                        }
                    }
                }
            }

            for (String s : suggestions) addSuggestionButton(s);

            // next-word suggestions placeholder (if ngrams exist)
            if (ngrams != null && ngrams.has(word)) {
                JSONArray arr = ngrams.optJSONArray(word);
                if (arr != null) {
                    for (int i = 0; i < arr.length() && suggestions.size() < max; i++) {
                        addSuggestionButton(arr.optString(i));
                    }
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "buildSuggestions error", e);
        }
    }

    private void addSuggestionButton(String text) {
        try {
            Button b = new Button(this);
            b.setText(text);
            b.setAllCaps(false);
            b.setMinWidth(120);
            b.setPadding(24, 8, 24, 8);
            b.setOnClickListener(v -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;

                // Replace last word with clicked suggestion
                CharSequence before = ic.getTextBeforeCursor(200, 0);
                if (before != null) {
                    String[] parts = before.toString().split("\\s+");
                    int len = parts.length > 0 ? parts[parts.length - 1].length() : 0;
                    ic.deleteSurroundingText(len, 0);
                }

                ic.commitText(text + " ", 1);
                updateBars();
            });
            suggestionsLayout.addView(b);
        } catch (Exception e) {
            Log.e(TAG, "addSuggestionButton error", e);
        }
    }

    private boolean isDarkMode() { return prefs.getBoolean(KEY_DARK, false); }
    private void toggleDarkMode() {
        prefs.edit().putBoolean(KEY_DARK, !isDarkMode()).apply();
        applyTheme();
    }
    private boolean isTranslateEnabled() { return prefs.getBoolean(KEY_TRANSLATE, true); }
    private void toggleTranslateEnabled() {
        prefs.edit().putBoolean(KEY_TRANSLATE, !isTranslateEnabled()).apply();
        updateBars();
    }

    private void applyTheme() {
        boolean dark = isDarkMode();

        if (translationText != null) {
            translationText.setBackgroundColor(dark ? 0xFF1C1C1E : 0xFFF2F2F7);
            translationText.setTextColor(dark ? 0xFFFFFFFF : 0xFF000000);
        }

        if (suggestionsLayout != null) {
            suggestionsLayout.setBackgroundColor(dark ? 0xFF2C2C2E : 0xFFF2F2F7);
        }

        if (kv != null) {
            kv.setBackgroundColor(dark ? 0xFF1C1C1E : 0xFFE5E5EA);
            kv.setKeyTextColor(dark ? 0xFFFFFFFF : 0xFF000000);
            kv.setPreviewEnabled(false);
            kv.setBackgroundResource(dark ? R.drawable.key_background_dark : R.drawable.key_background_light);
        }
    }

    @Override
    public void onKey(int primaryCode, int[] keyCodes) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        try {
            switch (primaryCode) {
                case -100: // toggle EN/IG
                    isIgbo = !isIgbo;
                    kv.setKeyboard(isIgbo ? keyboardIgbo : keyboardEnglish);
                    break;

                case -102: // symbols
                    kv.setKeyboard(keyboardSymbols);
                    break;

                case -103: // emoji page 1
                    emojiPage = 1;
                    kv.setKeyboard(emojiPage1);
                    break;

                case -302: // next emoji
                    emojiPage = Math.min(3, emojiPage + 1);
                    kv.setKeyboard(emojiPage == 1 ? emojiPage1 : (emojiPage == 2 ? emojiPage2 : emojiPage3));
                    break;

                case -303: // prev emoji
                    emojiPage = Math.max(1, emojiPage - 1);
                    kv.setKeyboard(emojiPage == 1 ? emojiPage1 : (emojiPage == 2 ? emojiPage2 : emojiPage3));
                    break;

                case -301: // back to ABC
                    kv.setKeyboard(isIgbo ? keyboardIgbo : keyboardEnglish);
                    break;

                case -105: // space
                    ic.commitText(" ", 1);
                    break;

                case -106: // enter
                    ic.commitText("\n", 1);
                    break;

                case -5: // delete with selection support; delete last word if none selected
                    CharSequence selected = ic.getSelectedText(0);
                    if (selected != null && selected.length() > 0) {
                        ic.commitText("", 1);
                    } else {
                        CharSequence before = ic.getTextBeforeCursor(200, 0);
                        if (before != null && before.length() > 0) {
                            String text = before.toString();
                            int lastSpace = text.lastIndexOf(' ');
                            int deleteCount = text.length() - (lastSpace + 1);
                            ic.deleteSurroundingText(deleteCount, 0);
                        } else {
                            ic.deleteSurroundingText(1, 0);
                        }
                    }
                    break;

                case -111: // dark mode toggle
                    toggleDarkMode();
                    break;

                case -110: // translate toggle
                    toggleTranslateEnabled();
                    break;

                case -101: // numbers
                    kv.setKeyboard(keyboardNumbers);
                    break;

                case -1: // shift
                    toggleShift();
                    break;

                default:
                    // normal character or emoji
                    commitCode(ic, primaryCode);
                    break;
            }
        } catch (Exception e) {
            Log.e(TAG, "onKey error: " + primaryCode, e);
        }

        updateBars();
    }

    private void toggleShift() {
        isShift = !isShift;
        Keyboard current = kv.getKeyboard();
        if (current == null) return;
        for (Keyboard.Key key : current.getKeys()) {
            if (key.label != null && key.label.length() == 1 && Character.isLetter(key.label.charAt(0))) {
                String s = key.label.toString();
                key.label = isShift ? s.toUpperCase(Locale.ROOT) : s.toLowerCase(Locale.ROOT);
                key.codes[0] = key.label.charAt(0);
            }
        }
        kv.invalidateAllKeys();
    }

    @Override public void onPress(int primaryCode) {}
    @Override public void onRelease(int primaryCode) {}
    @Override public void onText(CharSequence text) {}
    @Override public void swipeLeft() {
        // quick delete a word
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence before = ic.getTextBeforeCursor(200, 0);
        if (before != null && before.length() > 0) {
            String text = before.toString();
            int lastSpace = text.lastIndexOf(' ');
            int deleteCount = text.length() - (lastSpace + 1);
            ic.deleteSurroundingText(deleteCount, 0);
        }
        updateBars();
    }
    @Override public void swipeRight() {
        // accept first suggestion if present
        if (suggestionsLayout != null && suggestionsLayout.getChildCount() > 0) {
            View v = suggestionsLayout.getChildAt(0);
            v.performClick();
        }
    }
    @Override public void swipeUp() { toggleShift(); }
    @Override public void swipeDown() {}
}
