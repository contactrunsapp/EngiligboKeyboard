package com.engiligbo.otuekere;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class OnboardingActivity extends AppCompatActivity {

    Button btnEnable, btnSelect, btnContinue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);

        btnEnable = findViewById(R.id.btnEnableKeyboard);
        btnSelect = findViewById(R.id.btnSelectKeyboard);
        btnContinue = findViewById(R.id.btnContinue);

        btnEnable.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS);
            startActivity(intent);
        });

        btnSelect.setOnClickListener(v -> {
            getSystemService(android.view.inputmethod.InputMethodManager.class).showInputMethodPicker();
        });

        btnContinue.setOnClickListener(v -> finish());
    }
}
